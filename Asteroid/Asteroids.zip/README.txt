This project is based on the well known game, Asteroids.

You can play a version here: https://www.echalk.co.uk/amusements/Games/asteroidsClassic/ateroids.html
And you can read about it here: https://en.wikipedia.org/wiki/Asteroids_(video_game)
 
Command line arguments:
None

Controls:
    Esc - pauses the game
          Esc again quits the game
          pressing Up,Down,Left,Right,Space Continues game
    
    Game:
        Up              - move Forward
        Left            - rotate left
        Right           - rotate right
        Space bar       - Shoot



Required libraries: SDL2, SDL_ttf, math.h

Uses the following fonts:
    Arcade Classic (freeware for personal use)